package com.example.grandmediahelper

import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class OverlayService : Service() {
    companion object { const val ACTION_OCR_RESULT = "com.example.grandmediahelper.OCR_RESULT" }
    private lateinit var wm: WindowManager
    private var overlay: ScrollView? = null
    private var input: EditText? = null
    private var output: TextView? = null
    private var receiverRegistered = false

    private val ocrReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("recognizedText") ?: return
            input?.setText(text)
            output?.text = "Текст распознан. Нажми «Проверить и исправить»."
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFF2F4F7.toInt())
        }
        val header = TextView(this).apply {
            text = "ИИ СМИ • Grand Mobile     [закрыть]"
            textSize = 16f
            setTextColor(0xFF111827.toInt())
            setOnClickListener { stopSelf() }
        }
        input = EditText(this).apply {
            hint = "Распознанный текст объявления"
            minLines = 3
            maxLines = 7
            gravity = Gravity.TOP
        }
        output = TextView(this).apply {
            text = "Нажми «Распознать текст на экране» в основном приложении."
            textSize = 14f
            setTextColor(0xFF111827.toInt())
        }
        val check = Button(this).apply {
            text = "Проверить и исправить"
            setOnClickListener {
                val result = AdRules.check(input?.text?.toString() ?: "")
                output?.text = result.message
                if (result.corrected.isNotBlank()) input?.setText(result.corrected)
            }
        }
        val copy = Button(this).apply {
            text = "Копировать текст"
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Объявление", input?.text?.toString() ?: ""))
                output?.text = "Скопировано. Вернись в игру и вставь текст вручную."
            }
        }
        box.addView(header)
        box.addView(input)
        box.addView(check)
        box.addView(copy)
        box.addView(output)
        val scroll = ScrollView(this).apply { addView(box) }
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.9).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 80
        }
        wm.addView(scroll, params)
        overlay = scroll

        val filter = IntentFilter(ACTION_OCR_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(ocrReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(ocrReceiver, filter)
        receiverRegistered = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(ocrReceiver) } catch (_: Exception) {}
        }
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
}
