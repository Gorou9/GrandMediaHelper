package com.example.grandmediahelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "screen_ocr")
                .setContentTitle("ИИ СМИ Grand Mobile")
                .setContentText("Распознавание текста с экрана включено на один снимок")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("ИИ СМИ Grand Mobile")
                .setContentText("Распознавание текста")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .build()
        }
        startForeground(71, notification)

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>("resultData")
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    cleanup()
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))

            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            virtualDisplay = projection?.createVirtualDisplay(
                "GrandMediaOCR", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, null
            )
            Handler(Looper.getMainLooper()).postDelayed({ captureAndRecognize() }, 700)
        } catch (e: Exception) {
            sendResult("Не удалось захватить экран: ${e.message}")
            cleanup()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun captureAndRecognize() {
        val image = imageReader?.acquireLatestImage()
        if (image == null) {
            sendResult("Не удалось получить снимок экрана. Попробуй ещё раз.")
            cleanup()
            stopSelf()
            return
        }
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        image.close()
        val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        bitmap.recycle()

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(cropped, 0))
            .addOnSuccessListener { result ->
                val recognized = result.text.trim()
                sendResult(if (recognized.isBlank()) "Текст не найден. Открой объявление крупнее и повтори." else recognized)
            }
            .addOnFailureListener { e ->
                sendResult("Ошибка распознавания: ${e.localizedMessage ?: "неизвестная ошибка"}")
            }
            .addOnCompleteListener {
                recognizer.close()
                cropped.recycle()
                cleanup()
                stopSelf()
            }
    }

    private fun sendResult(text: String) {
        sendBroadcast(Intent(OverlayService.ACTION_OCR_RESULT).putExtra("recognizedText", text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("screen_ocr", "Распознавание экрана", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun cleanup() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        virtualDisplay = null
        imageReader = null
        projection = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }
}
