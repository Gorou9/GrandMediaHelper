package com.example.grandmediahelper

data class CheckResult(val message: String, val corrected: String = "")

object AdRules {
    private val places = linkedMapOf(
        "гарель" to "д. Гарель", "корякино" to "д. Корякино",
        "рыбацкая" to "д. Рыбацкая", "озёрная" to "д. Озёрная",
        "почтовая" to "д. Почтовая", "бусаево" to "п. Бусаево",
        "богатырево" to "п. Богатырево", "элитный" to "п. Элитный",
        "горячая штучка" to "п. Горячая Штучка", "батырево" to "пгт. Батырево",
        "лыткарино" to "пгт. Лыткарино", "эдово" to "пгт. Эдово",
        "южный" to "г. Южный", "арзамас" to "г. Арзамас"
    )

    fun check(raw: String): CheckResult {
        var text = raw.trim()
        if (text.isBlank()) return CheckResult("Сначала распознай экран или вставь текст объявления.")
        text = text.replace(Regex("\\s+"), " ")
        text = text.replace(Regex("\\bпродам\\b", RegexOption.IGNORE_CASE), "Продам")
            .replace(Regex("\\bкуплю\\b", RegexOption.IGNORE_CASE), "Куплю")
        text = text.replace(Regex("\\s*:\\s*"), ": ").replace(Regex("\\s+\\."), ".")
        places.forEach { (name, label) ->
            text = text.replace(
                Regex("\\bв\\s+(?:(?:д|пгт|п|г)\\.?\\s*)?${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE)
            ) { "в $label" }
        }
        if (text.isNotEmpty()) text = text.replaceFirstChar { it.uppercase() }

        val notes = mutableListOf<String>()
        if (text.contains("Продам", true) && !text.contains("Цена:", true))
            notes += "Возможно, не указана «Цена: ...»."
        if (text.contains("Куплю", true) && !text.contains("Бюджет:", true))
            notes += "Возможно, не указан «Бюджет: ...»."
        if (places.keys.any { text.contains(it, true) } &&
            !Regex("\\b(д\\.|п\\.|пгт\\.|г\\.)", RegexOption.IGNORE_CASE).containsMatchIn(text))
            notes += "Проверь сокращение населённого пункта: д., п., пгт. или г."
        notes += "Это базовая проверка: сверь итог с полными правилами сервера перед отправкой."
        return CheckResult(notes.joinToString("\\n• ", prefix = "Проверка:\\n• "), text)
    }
}
